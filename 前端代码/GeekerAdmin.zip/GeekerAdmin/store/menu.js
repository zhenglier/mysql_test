export default {
  namespaced: true,
  state: {
    // 将其放到公开访问界面
    menuList: [
      {
        id: 0,
        code: "home",
        name: "首页",
        icon: "s-home",
        path: "/home",
        children: []
      },
      {
        id: 1,
        code: "cost",
        name: "查询开销",
        icon: "s-home",
        path: "/cost",
        children: []
      }
    ]
  },
  mutations: {
    SET_MENU(state, menuList) {
      state.menuList = menuList;
    },
    CLEAR_MENU(state) {
      state.menuList = [
        {
          id: 0,
          code: "home",
          name: "首页",
          icon: "s-home",
          path: "/home",
          children: []
        }
      ];
    }
  }
};
