<template>
  <el-drawer :title="drawerProps.title" v-model="drawerVisible" :width="720">
    <el-form :model="drawerProps.row" ref="formRef" label-width="120px">
      <el-form-item label="售票员账户名">
        <el-input v-model="drawerProps.row.useraccount" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="乘客人身份证号码">
        <el-input v-model="drawerProps.row.p_id" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="列车编号">
        <el-input v-model="drawerProps.row.trainID" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="起始站">
        <el-input v-model="drawerProps.row.startStationNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
      <el-form-item label="终点站">
        <el-input v-model="drawerProps.row.endStationNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="drawerVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave" v-if="!drawerProps.isView">保存</el-button>
      </span>
    </template>
  </el-drawer>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { ElMessage, FormInstance } from "element-plus";

export interface DrawerProps {
  title: string;
  isView: boolean;
  row: Partial<infoForPerson>;
  api?: (params: any) => Promise<any>;
  getTableList?: () => void;
}
export interface infoForPerson {
  title: string;
  useraccount: string;
  p_id: string;
  trainID: string;
  startStationNumber: number;
  endStationNumber: number;
}
const drawerVisible = ref(false);
const drawerProps = ref<DrawerProps>({
  isView: false,
  title: "",
  row: {}
} as DrawerProps);

const acceptParams = (params: DrawerProps) => {
  console.log(params);
  drawerProps.value = params;
  if (params.title === "新增") {
    drawerVisible.value = true;
  }
  // else {
  //   async () => {
  //     await drawerProps.value.api!(drawerProps.value.row);
  //     ElMessage.success({ message: `${drawerProps.value.title}成功！` });
  //     drawerProps.value.getTableList!();
  //   };
  // }
};

const formRef = ref<FormInstance>();

const handleSave = async () => {
  if (!formRef.value) return;
  await formRef.value!.validate(async (valid: boolean) => {
    if (valid) {
      try {
        await drawerProps.value.api!(drawerProps.value.row);
        ElMessage.success({ message: `${drawerProps.value.title}成功！` });
        drawerProps.value.getTableList!();
        drawerVisible.value = false;
      } catch (error) {
        ElMessage.error("保存失败");
      }
    }
  });
};

defineExpose({
  acceptParams
});
</script>

<style scoped>
.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
