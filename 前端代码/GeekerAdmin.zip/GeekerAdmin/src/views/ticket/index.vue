<template>
  <div class="main-box">
    <div class="table-box">
      <ProTable
        ref="proTable"
        :columns="columns"
        :request-api="trainInfoApi"
        :init-param="initParam"
        :search-col="{ xs: 1, sm: 1, md: 2, lg: 4, xl: 1 }"
      >
        <template #tableHeader>
          <el-button type="primary" :icon="CirclePlus" @click="openDrawer('新增')">购票</el-button>
        </template>
        <template #operation="">
          <!-- <el-button type="primary" link :icon="View" @click="openDrawer(scope.row)">购买</el-button> -->
        </template>
      </ProTable>
      <tickDrawer ref="drawerRef" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from "vue";
import { ProTableInstance, ColumnProps } from "@/components/ProTable/interface";
import { entity } from "@/api/interface";
import { useUserStore } from "@/stores/modules/user";
import ProTable from "@/components/ProTable/index.vue";
import { trainInfoApi } from "@/api/modules/trainInfo";
import tickDrawer from "./tickDrawer.vue";
import { infoForPerson } from "./tickDrawer.vue";
import { buyTicket } from "@/api/modules/ticket";
const proTable = ref<ProTableInstance>();

const columns = reactive<ColumnProps<entity.trainInfo>[]>([
  { type: "index", label: "#" },
  { prop: "trainNumber", label: "列车号", width: 200 },
  { prop: "trainType", label: "列车类型", width: 200 },
  { prop: "carriageCount", label: "车厢数量", width: 150 },
  { prop: "departureStation", label: "出发站", width: 200, search: { el: "input" } },
  { prop: "destinationStation", label: "到达站", width: 200, search: { el: "input" } },
  { prop: "departureTime", label: "出发时间", width: 150 },
  { prop: "arrivalTime", label: "到达时间", width: 150 },
  { prop: "duration", label: "持续时间", width: 150 },
  { prop: "arrivalDate", label: "出发日期", width: 150, search: { el: "input" } },
  { prop: "operationStatus", label: "运行状态", width: 150 },
  { prop: "trainID", label: "列车ID", width: 200 },
  { prop: "operation", label: "操作", width: 200, fixed: "right" }
]);

const initParam = reactive({
  useraccount: useUserStore().userInfo.name
});
// const buyTicket = (params: entity.trainInfo) => {
//   console.log(params.departureStation);
//   // http.post<entity.trainInfo>("http://127.0.0.1:8088/ticket");
//   ElMessage.success(`购买成功，列车号为${params.trainNumber}`);
// };
const drawerRef = ref<InstanceType<typeof tickDrawer> | null>(null);
const openDrawer = (title: string, row: Partial<infoForPerson> = {}) => {
  const params = {
    title,
    isView: title === "查看",
    row: { ...row },
    api: title === "新增" ? buyTicket : undefined,
    getTableList: proTable.value?.getTableList
  };
  console.log("点击了按钮");
  drawerRef.value?.acceptParams(params);
  console.log("参数传递完成");
};
</script>
<style lang="scss" scoped></style>
