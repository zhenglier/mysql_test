<template>
  <el-drawer :title="drawerProps.title" v-model="drawerVisible" :width="720">
    <el-form :model="drawerProps.row" ref="formRef" label-width="120px">
      <el-form-item label="列车号">
        <el-input v-model="drawerProps.row.trainNumber" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="列车类型">
        <el-input v-model="drawerProps.row.trainType" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="车厢数量">
        <el-input v-model="drawerProps.row.carriageCount" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="出发站">
        <el-input v-model="drawerProps.row.departureStation" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="到达站">
        <el-input v-model="drawerProps.row.destinationStation" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="出发时间">
        <el-input v-model="drawerProps.row.departureTime" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="到达时间">
        <el-input v-model="drawerProps.row.arrivalTime" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="持续时间">
        <el-input v-model="drawerProps.row.duration" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="出发日期">
        <el-input v-model="drawerProps.row.arrivalDate" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="运行状态">
        <el-input v-model="drawerProps.row.operationStatus" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="列车ID">
        <el-input v-model="drawerProps.row.trainID" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="drawerVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave" v-if="!drawerProps.isView">保存</el-button>
      </span>
    </template>
  </el-drawer>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { ElMessage, FormInstance } from "element-plus";
import { entity } from "@/api/interface";

export interface DrawerProps {
  title: string;
  isView: boolean;
  row: Partial<entity.trainInfo>;
  api?: (params: any) => Promise<any>;
  getTableList?: () => void;
}
const drawerVisible = ref(false);
const drawerProps = ref<DrawerProps>({
  isView: false,
  title: "",
  row: {}
} as DrawerProps);

const acceptParams = (params: DrawerProps) => {
  console.log(params);
  drawerProps.value = params;
  drawerVisible.value = true;
};

const formRef = ref<FormInstance>();

const handleSave = async () => {
  if (!formRef.value) return;
  await formRef.value!.validate(async (valid: boolean) => {
    if (valid) {
      try {
        await drawerProps.value.api!(drawerProps.value.row);
        ElMessage.success({ message: `${drawerProps.value.title}成功！` });
        drawerProps.value.getTableList!();
        drawerVisible.value = false;
      } catch (error) {
        ElMessage.error("保存失败");
      }
    }
  });
};

defineExpose({
  acceptParams
});
</script>

<style scoped>
.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
