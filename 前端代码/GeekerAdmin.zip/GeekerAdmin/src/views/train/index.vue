<template>
  <div class="main-box">
    <div class="table-box">
      <ProTable
        ref="proTable"
        :columns="columns"
        :request-api="getAllTrainInfo"
        :init-param="initParam"
        :search-col="{ xs: 1, sm: 1, md: 2, lg: 3, xl: 3 }"
      >
        <template #tableHeader>
          <el-button type="primary" :icon="CirclePlus" @click="openDrawer('新增')">新增</el-button>
        </template>
        <template #operation="scope">
          <el-button type="primary" link :icon="View" @click="openDrawer('查看', scope.row)">查看</el-button>
        </template>
      </ProTable>
      <trainDrawer ref="drawerRef" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from "vue";
import { ProTableInstance, ColumnProps } from "@/components/ProTable/interface";
import { entity } from "@/api/interface";
import { useUserStore } from "@/stores/modules/user";
import ProTable from "@/components/ProTable/index.vue";
import { addTrainInfo, getAllTrainInfo } from "@/api/modules/trainInfo";
import TrainDrawer from "./trainDrawer.vue";
import { CirclePlus, View } from "@element-plus/icons-vue";
const proTable = ref<ProTableInstance>();

const columns = reactive<ColumnProps<entity.trainInfo>[]>([
  { type: "index", label: "#" },
  { prop: "trainNumber", label: "列车号", width: 200 },
  { prop: "trainType", label: "列车类型", width: 200, search: { el: "input" } },
  { prop: "carriageCount", label: "车厢数量", width: 150 },
  { prop: "departureStation", label: "出发站", width: 200 },
  { prop: "destinationStation", label: "到达站", width: 200 },
  { prop: "departureTime", label: "出发时间", width: 150 },
  { prop: "arrivalTime", label: "到达时间", width: 150 },
  { prop: "duration", label: "持续时间", width: 150 },
  { prop: "arrivalDate", label: "到达日期", width: 150 },
  { prop: "operationStatus", label: "运行状态", width: 150 },
  { prop: "trainID", label: "列车ID", width: 200 },
  { prop: "operation", label: "操作", width: 200, fixed: "right" }
]);

const initParam = reactive({
  useraccount: useUserStore().userInfo.name
});

const drawerRef = ref<InstanceType<typeof TrainDrawer> | null>(null);
const openDrawer = (title: string, row: Partial<entity.trainInfo> = {}) => {
  const params = {
    title,
    isView: title === "查看",
    row: { ...row },
    api: title === "新增" ? addTrainInfo : title === "查看" ? undefined : undefined,
    getTableList: proTable.value?.getTableList
  };
  console.log("点击了按钮");
  drawerRef.value?.acceptParams(params);
  console.log("参数传递完成");
};
</script>

<style lang="scss" scoped></style>
