<template>
  <el-drawer :title="drawerProps.title" v-model="drawerVisible" :width="720">
    <el-form :model="drawerProps.row" ref="formRef" label-width="120px">
      <el-form-item label="姓名">
        <el-input v-model="drawerProps.row.personname" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="性别">
        <el-select v-model="drawerProps.row.sex" :disabled="drawerProps.isView">
          <el-option label="Male" value="男"></el-option>
          <el-option label="Female" value="女"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="身份证号">
        <el-input v-model="drawerProps.row.id" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="地址">
        <el-input v-model="drawerProps.row.address" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="drawerVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave" v-if="!drawerProps.isView">保存</el-button>
      </span>
    </template>
  </el-drawer>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { ElMessage, FormInstance } from "element-plus";
import { entity } from "@/api/interface";
export interface DrawerProps {
  title: string;
  isView: boolean;
  row: Partial<entity.person>;
  api?: (params: any) => Promise<any>;
  getTableList?: () => void;
}
const drawerVisible = ref(false);
const drawerProps = ref<DrawerProps>({
  isView: false,
  title: "",
  row: {}
} as DrawerProps);
const acceptParams = (params: DrawerProps) => {
  console.log(params);
  drawerProps.value = params;
  drawerVisible.value = true;
};
const formRef = ref<FormInstance>();
const handleSave = async () => {
  if (!formRef.value) return;
  await formRef.value!.validate(async (valid: boolean) => {
    if (valid) {
      try {
        await drawerProps.value.api!(drawerProps.value.row as entity.person);
        ElMessage.success({ message: `${drawerProps.value.title}乘车人成功！` });
        drawerProps.value.getTableList!();
        drawerVisible.value = false;
      } catch (error) {
        ElMessage.error("保存失败");
      }
    }
  });
};
defineExpose({
  acceptParams
});
</script>

<style scoped>
.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
