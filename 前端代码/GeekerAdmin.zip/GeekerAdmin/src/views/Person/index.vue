<template>
  <div class="main-box">
    <!-- <TreeFilter
      label="name"
      title="部门列表(单选)"
      :request-api="getUserDepartment"
      :default-value="initParam.departmentId"
      @change="changeTreeFilter"
    /> -->
    <div class="table-box">
      <ProTable
        ref="proTable"
        :columns="columns"
        :request-api="personApi"
        :init-param="initParam"
        :search-col="{ xs: 1, sm: 1, md: 2, lg: 3, xl: 3 }"
      >
        <!-- 表格 header 按钮 -->
        <template #tableHeader>
          <el-button type="primary" :icon="CirclePlus" @click="openDrawer('新增')">新增乘车人</el-button>
          <!-- <el-button type="primary" :icon="Upload" plain @click="batchAdd">批量添加用户</el-button>
          <el-button type="primary" :icon="Download" plain @click="downloadFile">导出用户数据</el-button> -->
        </template>
        <!-- 表格操作 -->
        <template #operation="scope">
          <el-button type="primary" link :icon="View" @click="openDrawer('查看', scope.row)">查看</el-button>
          <!-- <el-button type="primary" link :icon="EditPen" @click="openDrawer('编辑', scope.row)">编辑</el-button>
          <el-button type="primary" link :icon="Refresh" @click="resetPass(scope.row)">重置密码</el-button>
          <el-button type="primary" link :icon="Delete" @click="deleteAccount(scope.row)">删除</el-button> -->
        </template>
      </ProTable>
      <personDrawer ref="drawerRef" />
      <!-- <ImportExcel ref="dialogRef" /> -->
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ref, reactive } from "vue";
import { ProTableInstance, ColumnProps } from "@/components/ProTable/interface";
import { entity } from "@/api/interface";
import { CirclePlus, View } from "@element-plus/icons-vue";
import { personApi, addPerson } from "@/api/modules/person";
import { useUserStore } from "@/stores/modules/user";
import personDrawer from "./personDrawer.vue";
import ProTable from "@/components/ProTable/index.vue";

const proTable = ref<ProTableInstance>();
const getSexLabel = sexValue => {
  switch (sexValue) {
    case "男":
      return "Male";
    case "女":
      return "Female";
    default:
      return "Other";
  }
};
const columns = reactive<ColumnProps<entity.person>[]>([
  { type: "index", label: "#" },
  { prop: "personname", label: "姓名", search: { el: "input" } },
  {
    prop: "sex",
    label: "性别",
    width: 100,
    sortable: true,
    search: { el: "select" },
    formatter: row => getSexLabel(row.sex),
    enum: () =>
      Promise.resolve([
        { label: "Male", value: "男" },
        { label: "Female", value: "女" }
      ])
  },
  { prop: "id", label: "身份证号", width: 380 },
  { prop: "address", label: "地址", width: 380, search: { el: "input" } },
  { prop: "operation", label: "操作", width: 200, fixed: "right" }
]);
const initParam = reactive({
  useraccount: useUserStore().userInfo.name
});
const drawerRef = ref<InstanceType<typeof personDrawer> | null>(null);
const openDrawer = (title: string, row: Partial<entity.person> = {}) => {
  const params = {
    title,
    isView: title === "查看",
    row: { ...row },
    api: title === "新增" ? addPerson : title === "编辑" ? addPerson : undefined,
    getTableList: proTable.value?.getTableList
  };
  console.log("点击了按钮");
  drawerRef.value?.acceptParams(params);
  console.log("参数传递完成");
};
// 如何直接使用伪删除
// 批量添加用户
// const dialogRef = ref<InstanceType<typeof ImportExcel> | null>(null);
// const batchAdd = () => {
//   const params = {
//     title: "用户",
//     tempApi: exportUserInfo,
//     importApi: BatchAddUser,
//     getTableList: proTable.value?.getTableList
//   };
//   dialogRef.value?.acceptParams(params);
// };
// 分页处理
</script>

<style lang="scss" scoped></style>
