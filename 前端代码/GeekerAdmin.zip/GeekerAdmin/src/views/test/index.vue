<template>
  <div></div>
</template>

<script lang="ts" setup>
// import { personApi } from "@/api/modules/person";
// import { useUserStore } from "@/stores/modules/user";
// const post_data = {
//   useraccount: useUserStore().userInfo.name
// };
// const data = await personApi(post_data);
// console.log(data);
</script>

<style lang="scss" scoped></style>
