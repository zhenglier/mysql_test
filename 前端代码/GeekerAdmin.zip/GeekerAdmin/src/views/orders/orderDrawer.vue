<template>
  <el-drawer :title="drawerProps.title" v-model="drawerVisible" :width="720">
    <el-form :model="drawerProps.row" ref="formRef" label-width="120px">
      <el-form-item label="订单ID">
        <el-input v-model="drawerProps.row.id" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="列车ID">
        <el-input v-model="drawerProps.row.trainid" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="起始站编号">
        <el-input v-model="drawerProps.row.startStationNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
      <el-form-item label="终点站编号">
        <el-input v-model="drawerProps.row.endStationNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
      <el-form-item label="车厢号">
        <el-input v-model="drawerProps.row.carriageNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
      <el-form-item label="座位号">
        <el-input v-model="drawerProps.row.seatNumber" :disabled="drawerProps.isView" type="number"></el-input>
      </el-form-item>
      <el-form-item label="出发时间">
        <el-input v-model="drawerProps.row.startTime" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="到达时间">
        <el-input v-model="drawerProps.row.endTime" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="订单创建时间">
        <el-input v-model="drawerProps.row.ordersCreatingTime" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
      <el-form-item label="订单状态">
        <el-input v-model="drawerProps.row.ordersStatus" :disabled="drawerProps.isView"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="drawerVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave" v-if="!drawerProps.isView">保存</el-button>
      </span>
    </template>
  </el-drawer>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { ElMessage, FormInstance } from "element-plus";
import { entity } from "@/api/interface";

export interface DrawerProps {
  title: string;
  isView: boolean;
  row: Partial<entity.order>;
  api?: (params: any) => Promise<any>;
  getTableList?: () => void;
}

const drawerVisible = ref(false);
const drawerProps = ref<DrawerProps>({
  isView: false,
  title: "",
  row: {}
} as DrawerProps);

const acceptParams = (params: DrawerProps) => {
  console.log(params);
  drawerProps.value = params;
  drawerVisible.value = true;
};

const formRef = ref<FormInstance>();

const handleSave = async () => {
  if (!formRef.value) return;
  await formRef.value!.validate(async (valid: boolean) => {
    if (valid) {
      try {
        await drawerProps.value.api!(drawerProps.value.row);
        ElMessage.success({ message: `${drawerProps.value.title}订单成功！` });
        drawerProps.value.getTableList!();
        drawerVisible.value = false;
      } catch (error) {
        ElMessage.error("保存失败");
      }
    }
  });
};

defineExpose({
  acceptParams
});
</script>

<style scoped>
.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
