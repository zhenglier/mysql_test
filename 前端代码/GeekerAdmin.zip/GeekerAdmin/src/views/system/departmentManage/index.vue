<template>
  <div class="card content-box">
    <span class="text"> 部门管理（待完善） 🍓🍇🍈🍉</span>
  </div>
</template>

<script setup lang="ts" name="departmentManage"></script>
