<template>
  <div class="card content-box">
    <span class="text"> 角色管理（待完善） 🍓🍇🍈🍉</span>
  </div>
</template>

<script setup lang="ts" name="roleManage"></script>
