<template>
  <div class="card content-box">
    <span class="text"> 系统日志（待完善） 🍓🍇🍈🍉</span>
  </div>
</template>

<script setup lang="ts" name="systemLog"></script>
