<template>
  <div class="card content-box">
    <span class="text"> 字典管理（待完善） 🍓🍇🍈🍉</span>
  </div>
</template>

<script setup lang="ts" name="dictManage"></script>
