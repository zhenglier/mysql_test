<template>
  <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" size="large">
    <el-form-item prop="username">
      <el-input v-model="loginForm.username" placeholder="username">
        <template #prefix>
          <el-icon class="el-input__icon">
            <user />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input v-model="loginForm.password" type="password" placeholder="password" show-password autocomplete="new-password">
        <template #prefix>
          <el-icon class="el-input__icon">
            <lock />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="telephonenumber">
      <el-input v-model="loginForm.telephonenumber" placeholder="password" show-password autocomplete="new-password">
        <template #prefix>
          <el-icon class="el-input__icon">
            <lock />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="email">
      <el-input v-model="loginForm.email" type="password" placeholder="password" show-password autocomplete="new-password">
        <template #prefix>
          <el-icon class="el-input__icon">
            <lock />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
  </el-form>
  <div class="login-btn">
    <el-button :icon="Promotion" round size="large" @click="resetForm(loginFormRef)"> 清空 </el-button>
    <el-button :icon="UserFilled" round size="large" type="primary" :loading="loading" @click="Register(loginForm)">
      注册
    </el-button>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import { Promotion, UserFilled } from "@element-plus/icons-vue";
import type { ElForm } from "element-plus";
import http from "@/api";

const router = useRouter();
// const userStore = useUserStore();
// const tabsStore = useTabsStore();
// const keepAliveStore = useKeepAliveStore();

type FormInstance = InstanceType<typeof ElForm>;
const loginFormRef = ref<FormInstance>();
const loginRules = reactive({
  username: [{ required: true, message: "请输入用户名", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }],
  telephonenumber: [{ required: true, message: "请输入电话号码", trigger: "blur" }],
  email: [{ required: true, message: "请输入邮箱", trigger: "blur" }]
});

const loading = ref(false);
const loginForm = reactive<any>({
  username: "",
  password: "",
  email: "",
  telephonenumber: ""
});
const Register = (params: any) => {
  http.post<any>("http://127.0.0.1:8088/register/add", params);
  ElMessage.success("注册成功请登录");
  router.push("/login");
};
// resetForm
const resetForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.resetFields();
};

// onMounted(() => {
//   // 监听 enter 事件（调用登录）
//   document.onkeydown = (e: KeyboardEvent) => {
//     e = (window.event as KeyboardEvent) || e;
//     if (e.code === "Enter" || e.code === "enter" || e.code === "NumpadEnter") {
//       if (loading.value) return;
//       login(loginFormRef.value);
//     }
//   };
// });
</script>

<style scoped lang="scss">
@import "../index.scss";
</style>
