<template>
  <div class="main-box">
    <div class="table-box">
      <ProTable
        ref="proTable"
        :columns="columns"
        :request-api="orderApi"
        :init-param="initParam"
        :search-col="{ xs: 1, sm: 1, md: 2, lg: 3, xl: 3 }"
      >
        <!-- <template #tableHeader>
          <el-button type="primary" :icon="CirclePlus" @click="openDrawer('新增')">新增订单</el-button>
        </template> -->
        <template #operation="scope">
          <el-button type="primary" link :icon="View" @click="_rejectTicket(scope.row.ordersnumber)">退票</el-button>
        </template>
      </ProTable>
      <orderDrawer ref="drawerRef" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from "vue";
import { ProTableInstance, ColumnProps } from "@/components/ProTable/interface";
import { orderApi } from "@/api/modules/order";
import { useUserStore } from "@/stores/modules/user";
import { View } from "@element-plus/icons-vue";
import { entity, reqPerson } from "@/api/interface";
import orderDrawer from "./orderDrawer.vue";
import ProTable from "@/components/ProTable/index.vue";
import { ElMessage } from "element-plus";
import { rejectTicket } from "@/api/modules/ticket";
const proTable = ref<ProTableInstance>();

const columns = reactive<ColumnProps<entity.order>[]>([
  { type: "index", label: "#" },
  { prop: "ordersnumber", label: "订单ID", width: 200 },
  { prop: "trainid", label: "列车ID", width: 200, search: { el: "input" } },
  { prop: "startStation", label: "起始站编号", width: 200 },
  { prop: "endStation", label: "终点站编号", width: 200 },
  { prop: "carriageNumber", label: "车厢号", width: 100 },
  { prop: "seatNumber", label: "座位号", width: 100 },
  { prop: "startTime", label: "出发时间", width: 150 },
  { prop: "endTime", label: "到达时间", width: 150 },
  { prop: "ordersCreatingTime", label: "订单创建时间", width: 200 },
  { prop: "ordersStatus", label: "订单状态", width: 150 },
  { prop: "operation", label: "操作", width: 200, fixed: "right" }
]);
const _rejectTicket = (trainNumber: number) => {
  console.log(trainNumber);
  rejectTicket({ trainNumber });
  const data = ref<reqPerson>({
    pageSize: 10,
    pageNum: 1,
    useraccount: useUserStore().userInfo.name
  });
  orderApi(data.value);
  ElMessage.success(`退票成功，列车号为${trainNumber}`);
};
const initParam = reactive({
  useraccount: useUserStore().userInfo.name
});

// const drawerRef = ref<InstanceType<typeof orderDrawer> | null>(null);
// const openDrawer = (title: string, row: Partial<entity.order> = {}) => {
//   const params = {
//     title,
//     isView: title === "查看",
//     row: { ...row },
//     api: title === "新增" ? addOrder : undefined,
//     getTableList: proTable.value?.getTableList
//   };
//   console.log("点击了按钮");
//   drawerRef.value?.acceptParams(params);
//   console.log("参数传递完成");
// };
</script>

<style lang="scss" scoped></style>
