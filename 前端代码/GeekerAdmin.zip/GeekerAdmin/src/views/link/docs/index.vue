<template>
  <div class="card content-box">
    <span class="text"> 项目文档： <a href="https://docs.spicyboy.cn" target="_blank">https://docs.spicyboy.cn</a> 🍒🍉🍊 </span>
  </div>
</template>

<script setup lang="ts" name="docs"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
