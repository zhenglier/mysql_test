<template>
  <div class="card content-box">
    <span class="text">
      Gitee 仓库：
      <a href="https://gitee.com/HalseySpicy/Geeker-Admin" target="_blank">https://gitee.com/HalseySpicy/Geeker-Admin</a> 🍒🍉🍊
    </span>
  </div>
</template>

<script setup lang="ts" name="gitee"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
