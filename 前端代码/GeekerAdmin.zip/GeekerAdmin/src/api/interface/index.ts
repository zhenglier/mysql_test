import { extend } from "dayjs";

// 请求响应参数（不包含data）
export enum enum_seattype {
  硬座,
  软座
}
export enum enum_sex {
  男,
  女
}

export interface Result {
  code: string;
  msg: string;
}

// 请求响应参数（包含data）
export interface ResultData<T = any> extends Result {
  data: T;
}

// 分页响应参数
export interface ResPage<T> {
  list: T[];
  pageNum: number;
  pageSize: number;
  total: number;
}

// 分页请求参数
export interface ReqPage {
  pageNum: number;
  pageSize: number;
}

// 文件上传模块
export namespace Upload {
  export interface ResFileUrl {
    fileUrl: string;
  }
}

// 登录模块
export namespace Login {
  export interface ReqLoginForm {
    username: string;
    password: string;
  }
  export interface ResLogin {
    access_token: string;
  }
  export interface ResAuthButtons {
    [key: string]: string[];
  }
}

// 用户管理模块
export namespace User {
  export interface ReqUserParams extends ReqPage {
    username: string;
    gender: number;
    idCard: string;
    email: string;
    address: string;
    createTime: string[];
    status: number;
  }
  export interface ResUserList {
    id: string;
    username: string;
    gender: number;
    user: { detail: { age: number } };
    idCard: string;
    email: string;
    address: string;
    createTime: string;
    status: number;
    avatar: string;
    photo: any[];
    children?: ResUserList[];
  }
  export interface ResStatus {
    userLabel: string;
    userValue: number;
  }
  export interface ResGender {
    genderLabel: string;
    genderValue: number;
  }
  export interface ResDepartment {
    id: string;
    name: string;
    children?: ResDepartment[];
  }
  export interface ResRole {
    id: string;
    name: string;
    children?: ResDepartment[];
  }
}
// 注册用户模块模块
export namespace user {
  export interface user {
    useraccount: string;
    id: string;
    telephonenumber: string;
    password: string;
    email: string;
    userstype: string;
  }
}
// 交互过程中存在的实体类
export namespace entity {
  export interface carriage {
    trainnumber: number;
    carriagenumber: number;
    seattype: enum_seattype;
  }
  export interface person {
    id: string;
    personname: string;
    sex: enum_sex;
    address: string;
  }
  export interface order {
    ordersnumber: number;
    id: string;
    trainid: string;
    startStation: string;
    endStation: string;
    carriageNumber: number;
    seatNumber: number;
    startTime: string;
    endTime: string;
    ordersCreatingTime: string;
    ordersStatus: string;
  }
  export interface trainInfo {
    trainNumber: number;
    trainType: string;
    carriageCount: number;
    departureStation: string;
    destinationStation: string;
    departureTime: string; // Assuming you will use string to represent Time in TS
    arrivalTime: string; // Assuming you will use string to represent Time in TS
    duration: string; // Assuming you will use string to represent Time in TS
    arrivalDate: string; // Assuming you will use string to represent Date in TS
    operationStatus: string;
    trainID: string;
  }
}
export interface reqPerson {
  pageNum: number;
  pageSize: number;
  useraccount: string;
}
export interface reqSearch {
  departureStation: string;
  destinationStation: string;
  arrivelTime: string;
}
export interface reqReject {
  trainNumber: number;
}
