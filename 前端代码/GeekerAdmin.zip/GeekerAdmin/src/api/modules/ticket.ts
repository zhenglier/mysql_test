// import { trainInfo } from './../interface/index';
import { ResPage, Result, entity, reqReject } from "@/api/interface/index";
import http from "@/api";
export const ticketSearch = (params: any) => {
  return http.post<ResPage<entity.trainInfo>>("http://127.0.0.1:8088/ticket/search", params);
};
export const buyTicket = (params: any) => {
  return http.post<ResPage<entity.trainInfo>>("http://127.0.0.1:8088/ticket/buy", params);
};
export const rejectTicket = (params: reqReject) => {
  return http.post<Result>("http://127.0.0.1:8088/ticket/reject", params);
};
