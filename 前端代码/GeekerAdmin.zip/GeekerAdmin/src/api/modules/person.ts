// import { editUser } from './user';
import { entity, reqPerson, ResPage } from "@/api/interface/index";
import http from "@/api";
export const personApi = (params: reqPerson) => {
  return http.post<ResPage<entity.person>>("http://127.0.0.1:8088/person/getList", params);
};
export const addPerson = (params: entity.person) => {
  return http.post<entity.person>("http://127.0.0.1:8088/person/addperson", params);
};
