import { ResPage } from "./../interface/index";
import http from "@/api";
import { reqPerson, entity } from "../interface";
export interface userprice {
  user_account: string;
  price: string;
  start: string;
  end: string;
}
export interface Timese {
  start: string;
  end: string;
}
export interface user_price {
  user_account: string;
  price: string;
}
export const orderApi = (params: reqPerson) => {
  return http.post<ResPage<entity.order>>("http://127.0.0.1:8088/order/getorders", params);
};
export const getPrice = (params: Timese) => {
  http.post<ResPage<user_price>>("http://127.0.0.1:8088/root/getuserprice", params);
};
