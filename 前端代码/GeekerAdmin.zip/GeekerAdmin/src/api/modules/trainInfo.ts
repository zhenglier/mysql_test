import http from "@/api";
import { ResPage, reqPerson, entity } from "../interface";
export const trainInfoApi = (params: reqPerson) => {
  return http.post<ResPage<entity.trainInfo>>("http://127.0.0.1:8088/trainInfo/getinfo", params);
};
export const getAllTrainInfo = (params: reqPerson) => {
  return http.post<ResPage<entity.trainInfo>>("http://127.0.0.1:8088/trainInfo/getall", params);
};
export const addTrainInfo = (params: entity.trainInfo) => {
  return http.post<any>("http://127.0.0.1:8088/trainInfo/add", params);
};
