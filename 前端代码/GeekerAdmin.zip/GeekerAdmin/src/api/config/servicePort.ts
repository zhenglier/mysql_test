// 后端微服务模块前缀
export const PORT1 = "/geeker";
export const PORT2 = "/hooks";
