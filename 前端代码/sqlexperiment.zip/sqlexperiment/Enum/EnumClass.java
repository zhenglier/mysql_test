package com.example.sqlexperiment.Enum;


/**
 * @jxz 常用枚举
 */
public class EnumClass {
    public enum  Sex{
        男,女 ;
    }
    public enum PassengerType{
        成人,儿童,学生,残军
    }
    public enum OperationStatus{
        运行中,未运行,延迟
    }
    public enum OrderStatus{
        待支付 , 已取消, 待出行, 候补中, 已完成
    }
    public enum SeatStatus{
        空闲, 已预定, 已占用
    }
    

}
