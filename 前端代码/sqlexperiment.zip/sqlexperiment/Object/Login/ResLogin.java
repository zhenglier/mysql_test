package com.example.sqlexperiment.Object.Login;

public class ResLogin {
    private String access_token;

    public ResLogin(String access_token){
        this.access_token = access_token;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }
}
