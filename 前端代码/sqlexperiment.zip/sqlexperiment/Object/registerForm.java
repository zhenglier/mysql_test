package com.example.sqlexperiment.Object;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class registerForm {
    @JsonProperty("username")
    private String usersaccount;
    private  String id;
    private String telephonenumber;
    private String password;
    private String email;
    private String userstype = "普通用户";
}
