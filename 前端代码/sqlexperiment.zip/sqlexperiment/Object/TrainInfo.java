package com.example.sqlexperiment.Object;

import java.sql.Time;
import java.sql.Date;
import java.sql.Timestamp;
import com.example.sqlexperiment.Mapper.operationstatus;

public class TrainInfo {
    private Integer trainNumber;
    private String trainType;
    private Integer carriageCount;
    private String departureStation;
    private String destinationStation;
    private String departureTime;
    private String arrivalTime;
    private String duration;
    private String arrivalDate;
    private operationstatus operationStatus;
    private String trainID;


    public Integer getTrainNumber() {
        return trainNumber;
    }

    public void setTrainNumber(Integer trainNumber) {
        this.trainNumber = trainNumber;
    }

    public String getTrainType() {
        return trainType;
    }

    public void setTrainType(String trainType) {
        this.trainType = trainType;
    }

    public Integer getCarriageCount() {
        return carriageCount;
    }

    public void setCarriageCount(Integer carriageCount) {
        this.carriageCount = carriageCount;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public void setDepartureStation(String departureStation) {
        this.departureStation = departureStation;
    }

    public String getDestinationStation() {
        return destinationStation;
    }

    public void setDestinationStation(String destinationStation) {
        this.destinationStation = destinationStation;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public operationstatus getOperationStatus() {
        return operationStatus;
    }

    public void setOperationStatus(operationstatus operationStatus) {
        this.operationStatus = operationStatus;
    }

    public String getTrainID() {
        return trainID;
    }

    public void setTrainID(String trainID) {
        this.trainID = trainID;
    }


}

