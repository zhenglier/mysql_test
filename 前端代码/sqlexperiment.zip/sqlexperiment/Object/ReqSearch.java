package com.example.sqlexperiment.Object;

import java.sql.Time;

// 由于是直接返回的所以直接使用字符串对比
public class ReqSearch {
    private String departureStation; //出发站点
    private String destinationStation; // 抵达站点
    private String arrivelTime; // 出发日期

    private Integer pageNum;

    private Integer pageSize;

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public void setDepartureStation(String departureStation) {
        this.departureStation = departureStation;
    }

    public String getDestinationStation() {
        return destinationStation;
    }

    public void setDestinationStation(String destinationStation) {
        this.destinationStation = destinationStation;
    }

    public String getArrivelTime() {
        return arrivelTime;
    }

    public void setArrivelTime(String arrivelTime) {
        this.arrivelTime = arrivelTime;
    }
}
