package com.example.sqlexperiment.Object;

public class UserPrice {
    private String user_account;
    private int price;

    public String getUseraccount() {
        return user_account;
    }

    public void setUseraccount(String useraccount) {
        this.user_account = useraccount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
