package com.example.sqlexperiment.Object;


import jdk.jfr.DataAmount;
import lombok.Data;

@Data
public class ticketBuy {
    private String useraccount;
    private String p_id;
    private String trainID;
    private Integer startStationNumber;

    private Integer endStationNumber;

}
