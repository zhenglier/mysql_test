package com.example.sqlexperiment.Object.entity;

import com.example.sqlexperiment.Enum.EnumClass;

public class Person {
    private  String id;
    private  String personname;
    private EnumClass.Sex sex;
    private String address;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPersonname() {
        return personname;
    }

    public void setPersonname(String personname) {
        this.personname = personname;
    }

    public EnumClass.Sex getSex() {
        return sex;
    }

    public void setSex(EnumClass.Sex sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
