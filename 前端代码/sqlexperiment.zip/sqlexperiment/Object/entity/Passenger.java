package com.example.sqlexperiment.Object.entity;

public class Passenger {
    private String useraccount;
    private String id;
    private String telephonenumber;
    private String passengertype;

    public String getUseraccount() {
        return useraccount;
    }

    public void setUseraccount(String useraccount) {
        this.useraccount = useraccount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTelephonenumber() {
        return telephonenumber;
    }

    public void setTelephonenumber(String telephonenumber) {
        this.telephonenumber = telephonenumber;
    }

    public String getPassengertype() {
        return passengertype;
    }

    public void setPassengertype(String passengertype) {
        this.passengertype = passengertype;
    }
}
