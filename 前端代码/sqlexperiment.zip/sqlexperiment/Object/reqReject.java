package com.example.sqlexperiment.Object;

public class reqReject {
    private Integer trainNumber;

    public Integer getTrainNumber() {
        return trainNumber;
    }

    public void setTrainNumber(Integer trainNumber) {
        this.trainNumber = trainNumber;
    }
}
