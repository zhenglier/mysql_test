package com.example.sqlexperiment.Object;

import java.sql.Time;
import java.sql.Timestamp;

public class Order {
    private Integer ordersnumber;

    private String id;
    private String trainid;
    private String startStation;

    public Integer getOrdersnumber() {
        return ordersnumber;
    }

    public void setOrdersnumber(Integer ordersnumber) {
        this.ordersnumber = ordersnumber;
    }

    public String getTrainid() {
        return trainid;
    }

    public void setTrainid(String trainid) {
        this.trainid = trainid;
    }

    private String endStation;
    private String carriageNumber;
    private int seatNumber;
    private Time startTime;
    private Time endTime;
    private Timestamp ordersCreatingTime;
    private String ordersStatus;
    private String endStationNumber;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getStartStation() {
        return startStation;
    }

    public void setStartStation(String startStation) {
        this.startStation = startStation;
    }

    public String getEndStation() {
        return endStation;
    }

    public void setEndStationNumber(String endStationNumber) {
        this.endStationNumber = endStationNumber;
    }

    public String getCarriageNumber() {
        return carriageNumber;
    }

    public void setCarriageNumber(String carriageNumber) {
        this.carriageNumber = carriageNumber;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public Timestamp getOrdersCreatingTime() {
        return ordersCreatingTime;
    }

    public void setOrdersCreatingTime(Timestamp ordersCreatingTime) {
        this.ordersCreatingTime = ordersCreatingTime;
    }

    public String getOrdersStatus() {
        return ordersStatus;
    }

    public void setOrdersStatus(String ordersStatus) {
        this.ordersStatus = ordersStatus;
    }
}

