package com.example.sqlexperiment.Object;

public interface ReqPage {
     Integer pageNum = 0;
     Integer pageSize = 0;

     void getPageNum();

     void getPageSize();

     void setPageNum();

     void setPageSize();
}
