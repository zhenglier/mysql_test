package com.example.sqlexperiment.Object;

import org.springframework.boot.autoconfigure.integration.IntegrationAutoConfiguration;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.List;

public class ResPage<T> {
    List<T> list = null;
    Integer pageNum;

    @Override
    public String toString() {
        return "ResPage{" +
                "list=" + list +
                ", pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", total=" + total +
                '}';
    }

    Integer pageSize;
    Integer total;

    public ResPage(List<T> list, Integer pageNum, Integer pageSize, Integer total){
        this.list = list;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.total = total;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}
