package com.example.sqlexperiment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlExperimentApplication {

    public static void main(String[] args) {
        SpringApplication.run(SqlExperimentApplication.class, args);
    }

}
