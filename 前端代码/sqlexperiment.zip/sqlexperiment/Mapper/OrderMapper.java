package com.example.sqlexperiment.Mapper;

import com.example.sqlexperiment.Object.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.domain.Sort;

import java.util.List;

@Mapper
public interface OrderMapper {
       @Select("select * from show_all_orders(#{useraccount})")
       List<Order>getAllOrders(String useraccount);

       @Select("call book_seat_and_create_order()")
       void buyTickets();


}
