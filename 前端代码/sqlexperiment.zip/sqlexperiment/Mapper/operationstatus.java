package com.example.sqlexperiment.Mapper;

public enum operationstatus{
    未运行,运行中,延迟
}
