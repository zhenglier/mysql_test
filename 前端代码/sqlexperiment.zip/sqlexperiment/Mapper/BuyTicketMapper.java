package com.example.sqlexperiment.Mapper;


import com.example.sqlexperiment.Object.ReqSearch;
import com.example.sqlexperiment.Object.entity.Passenger;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import com.example.sqlexperiment.Object.TrainInfo;
import com.example.sqlexperiment.Object.ticketBuy;
import com.example.sqlexperiment.Object.reqReject;
import java.util.List;

@Mapper
public interface BuyTicketMapper {
    @Select("select add_passenger(#{useraccount}, #{id},#{telephonenumber}, #{passengertype})")
    void add_passenger(Passenger passenger);  // 向表中新增一名乘客

    @Select("select * from query_train_in_ticket(#{departureStation}, #{destinationStation}, #{arrivelTime})")
    List<TrainInfo>searchTrainInfo(ReqSearch reqSearch);

    @Select("select book_seat_and_create_order(#{useraccount}, #{p_id},#{trainID}, #{startStationNumber}, #{endStationNumber})")
    Integer buyTicket(ticketBuy ticketinfo);

    @Insert("select cancel_unpaid_orders(#{trainNumber})")
    void rejectTicket(reqReject reqject);

}
