package com.example.sqlexperiment.Mapper.Login;


import com.example.sqlexperiment.Object.UserPrice;
import com.example.sqlexperiment.Object.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import com.example.sqlexperiment.Object.registerForm;

import java.sql.Timestamp;
import java.util.List;

@Mapper
public interface UserMapper {
    @Select("select * from users where usersaccount=#{useraccount}")
    User getUserByAccount(String useraccount);

    @Select("select * from query_sum_price(#{start}::timestamp without time zone, #{end}::timestamp without time zone)")
    List<UserPrice>getUserPrice(String start, String end);

    @Insert("insert into users values (#{usersaccount}, #{id},#{telephonenumber},#{password},#{email},#{userstype})")
    void addUser(registerForm reg);
}

