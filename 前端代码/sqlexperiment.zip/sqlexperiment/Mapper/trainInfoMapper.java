package com.example.sqlexperiment.Mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import com.example.sqlexperiment.Object.TrainInfo;
import java.util.List;
import com.example.sqlexperiment.Mapper.operationstatus;
@Mapper
public interface trainInfoMapper {
    @Select("select trainnumber,traintype,carriagecount," +
            "(select stationname from station where departurestation=stationnumber) as departurestation," +
            "(select stationname from station where destinationstation=stationnumber) as destinationstation," +
            "departuretime,arrivaltime,duration,arrivaldate,operationstatus,trainid,seatcount from trainInfo")
    List<TrainInfo>getTrainInfo();

//    @Insert("insert  to val")
//    void addTrainInfo(TrainInfo trainInfo);

    @Select("select * from trainInfo")
    List<TrainInfo>getAllInfo();


    @Insert("insert into trainInfo values(#{trainNumber}, #{trainType}, #{carriageCount}, #{departureStation}, #{destinationStation}, #{departureTime}::time without time zone, #{arrivalTime}::time without time zone, #{duration}::time without time zone, #{arrivalDate}::timestamp without time zone, #{operationStatus}::operation_status, #{trainID})")
    void insertToTrainfo(TrainInfo trainInfo);
}