package com.example.sqlexperiment.Mapper;


import com.example.sqlexperiment.Object.entity.Person;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import javax.print.DocFlavor;
import java.util.List;

@Mapper
public interface PersonMapper {
    @Select("select * from person ")
    List<Person>getPersonById(String id);

    @Select("insert into person values(#{id}, #{personname}, #{sex}::sex, #{address})")
    void addPerson(Person person);

    @Select("update person set id = #{id}, personname = #{personname}, sex = #{sex}, address = #{address}")
    void editPerson(Person person);

}
