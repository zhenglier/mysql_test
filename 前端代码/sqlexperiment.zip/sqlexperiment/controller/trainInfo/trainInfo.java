package com.example.sqlexperiment.controller.trainInfo;

import com.example.sqlexperiment.Object.ReqPerson;
import com.example.sqlexperiment.Object.TrainInfo;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.sqlexperiment.Mapper.trainInfoMapper;


import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/trainInfo")
public class trainInfo {

    @Autowired
    private trainInfoMapper traininfoMapper;

    @PostMapping("/getinfo")
    ResponseEntity<String>getinfo(@RequestBody ReqPerson reqPerson){
        List<TrainInfo> result_trainInfo = this.traininfoMapper.getTrainInfo();
        Integer pageNum = reqPerson.getPageNum(); // 获取当前请求页
        Integer pageSize = reqPerson.getPageSize();
        int len = result_trainInfo.size();
        int t_len = Math.min(len, pageNum*pageSize);
        List<TrainInfo> result = new ArrayList<>();
        System.out.println(t_len);
        System.out.println((pageNum -  1)*pageSize);
        for(int i = (pageNum - 1)*pageSize; i < t_len; ++i){
            result.add(result_trainInfo.get(i));
        }
        JSONObject res = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("list", result);
        data.put("pageNum",pageNum);
        data.put("pageSize",pageSize);
        res.put("data", data);

        return ResponseEntity.ok(res.toString());
    }

    @PostMapping("/getall")
    ResponseEntity<String>getAllInfo(@RequestBody ReqPerson reqPerson){
        List<TrainInfo> result_trainInfo = this.traininfoMapper.getAllInfo();
        Integer pageNum = reqPerson.getPageNum(); // 获取当前请求页
        Integer pageSize = reqPerson.getPageSize();
        int len = result_trainInfo.size();
        int t_len = Math.min(len, pageNum*pageSize);
        List<TrainInfo> result = new ArrayList<>();
        System.out.println(t_len);
        System.out.println((pageNum -  1)*pageSize);
        for(int i = (pageNum - 1)*pageSize; i < t_len; ++i){
            result.add(result_trainInfo.get(i));
        }
        JSONObject res = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("list", result);
        data.put("pageNum",pageNum);
        data.put("pageSize",pageSize);
        res.put("data", data);

        return ResponseEntity.ok(res.toString());
    }

    @RequestMapping("/add")
    ResponseEntity<?> addTrainInfo(@RequestBody TrainInfo trainInfo){
        this.traininfoMapper.insertToTrainfo(trainInfo);
        return ResponseEntity.ok("success");
    }

}
