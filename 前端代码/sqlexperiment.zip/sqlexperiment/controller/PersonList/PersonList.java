package com.example.sqlexperiment.controller.PersonList;

import com.example.sqlexperiment.Mapper.Login.UserMapper;
import com.example.sqlexperiment.Mapper.PersonMapper;
import com.example.sqlexperiment.Object.ReqPerson;
import com.example.sqlexperiment.Object.ResPage;
import com.example.sqlexperiment.Object.entity.Person;
import com.example.sqlexperiment.Object.entity.User;
import com.fasterxml.jackson.databind.util.JSONPObject;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping("/person")
public class PersonList {
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PersonMapper personMapper;
    // 前端请求分页策略

    @PostMapping("/getList")
    ResponseEntity<String> getPerson(@RequestBody ReqPerson reqPerson){
        User _user = userMapper.getUserByAccount(reqPerson.getUseraccount());
        List<Person> result_person = personMapper.getPersonById(_user.getId());
        System.out.println(result_person);
        int pageSize = 10;
        int pageNum = 1;
        int len = result_person.size();
        List<Person> result = new ArrayList<>();
        System.out.println(len);
        int t_len = Math.min(pageNum*pageSize,len);
        for(int i = (pageNum - 1)*pageSize; i < t_len; ++i){
             result.add(result_person.get(i));
        }
        JSONObject res = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("list",result);
        res.put("data", data);
        res.put("pageNum", pageNum);
        res.put("pageSize", pageSize);
        res.put("total",len);
        return ResponseEntity.ok(res.toString());
    }
}
