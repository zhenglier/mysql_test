package com.example.sqlexperiment.controller.PersonList;


import com.example.sqlexperiment.Mapper.PersonMapper;
import com.example.sqlexperiment.Object.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/person")
public class UpdatePerson {
    @Autowired
    private PersonMapper personMapper;

    @PostMapping("/addperson")
    ResponseEntity<String> addPerson(@RequestBody Person person){
        this.personMapper.addPerson(person);
        return ResponseEntity.ok("success");
    }

    @PostMapping("/editperson")
    ResponseEntity<String>editPerson(@RequestBody Person person){
        this.personMapper.editPerson(person);
        return ResponseEntity.ok("success");
    }
}
