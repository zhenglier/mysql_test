package com.example.sqlexperiment.controller;


import com.example.sqlexperiment.Mapper.Login.UserMapper;
import com.example.sqlexperiment.Object.Timese;
import com.example.sqlexperiment.Object.UserPrice;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/root")
public class AllUsers {

    @Autowired
    private UserMapper userMapper;
    @RequestMapping("/getuserprice")
    ResponseEntity<String>getUserPrice(@RequestBody Timese se){
        int pageSize = 10;
        int pageNum  = 1;
        List<UserPrice>result_se = userMapper.getUserPrice(se.getStart(), se.getEnd());
        JSONObject data = new JSONObject();
        JSONObject res = new JSONObject();
        data.put("list",result_se);
        res.put("pageSize",pageSize);
        res.put("pageNum",pageNum);
        res.put("total",result_se.size());
        res.put("data",data);
        return ResponseEntity.ok(res.toString());
    }
}
