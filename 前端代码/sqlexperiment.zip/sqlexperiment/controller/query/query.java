package com.example.sqlexperiment.controller.query;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/query")
public class query {

}
