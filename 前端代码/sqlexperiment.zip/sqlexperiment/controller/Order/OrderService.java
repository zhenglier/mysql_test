package com.example.sqlexperiment.controller.Order;


import com.example.sqlexperiment.Mapper.OrderMapper;
import com.example.sqlexperiment.Object.Order;
import com.example.sqlexperiment.Object.ReqPerson;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.xml.transform.Result;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderService {

    @Autowired
   private OrderMapper orderMapper;

   @PostMapping("/getorders")
    ResponseEntity<String>getOrders(@RequestBody ReqPerson reqPerson){
       Integer pageSize = reqPerson.getPageSize();
       Integer pageNum = reqPerson.getPageNum();
       List<Order>result = this.orderMapper.getAllOrders(reqPerson.getUseraccount());
       int len = result.size();
       int t_len = Math.min(pageNum*pageSize, len);
      System.out.println(reqPerson.getUseraccount());
       List<Order>result_order = new ArrayList<>();
       System.out.println(result.get(0).toString());
       System.out.println(pageNum - 1);
       System.out.println(t_len);
       for(int i = (pageNum - 1)*pageSize; i < t_len; ++i){
           result_order.add(result.get(i));
       }
       System.out.println(result_order);
       JSONObject res = new JSONObject();
       JSONObject data = new JSONObject();
       data.put("list",result_order);
       res.put("pageSize", pageSize);
       res.put("pageNum", pageNum);
       res.put("total", len);
       res.put("data", data);
       return ResponseEntity.ok(res.toString());
   }
}
