package com.example.sqlexperiment.controller;

import com.example.sqlexperiment.Mapper.Login.UserMapper;
import com.fasterxml.jackson.databind.deser.impl.MergingSettableBeanProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.sqlexperiment.Object.registerForm;

@RestController
@RequestMapping("/register")
public class Register {
    @Autowired
    private UserMapper userMapper;


    @RequestMapping("/add")
    public ResponseEntity<String> addUser(@RequestBody registerForm reg){

        this.userMapper.addUser(reg);
        return ResponseEntity.ok("success");
    }

}
