package com.example.sqlexperiment.controller.TicketService;


import com.example.sqlexperiment.Mapper.BuyTicketMapper;
import com.example.sqlexperiment.Object.ReqSearch;
import com.example.sqlexperiment.Object.TrainInfo;
import com.example.sqlexperiment.Object.entity.Passenger;
import org.apache.ibatis.annotations.Mapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.sqlexperiment.Object.ticketBuy;
import com.example.sqlexperiment.Object.reqReject;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;


/**
 * 实现一系列的火车票服务操作
 */
@RequestMapping("/ticket")
@Controller
public class TicketService {

    @Autowired
    private BuyTicketMapper buyTicketMapper;

    @RequestMapping("/add_passengeer")
    void add_passenger(@RequestBody Passenger passenger){
        this.buyTicketMapper.add_passenger(passenger);
    }


    @RequestMapping("/search")
    ResponseEntity<String>getSearch(@RequestBody ReqSearch reqSearch){
        Integer pageNum = reqSearch.getPageNum();
        Integer pageSize = reqSearch.getPageSize();
        System.out.println(reqSearch.getArrivelTime());
        System.out.println(reqSearch.getDepartureStation());
        System.out.println(reqSearch.getDestinationStation());
        List<TrainInfo>result_trainInfo =  this.buyTicketMapper.searchTrainInfo(reqSearch);
        JSONObject data = new JSONObject();
        JSONObject res = new JSONObject();
        // 要进行分页
        List<TrainInfo>result = new ArrayList<>();
        int len = result_trainInfo.size();
        int t_len = Math.min(len, pageNum*pageSize);
        System.out.println(len);
        for (int i = (pageNum - 1)*pageSize; i < len; ++i){
            result.add(result_trainInfo.get(i));
        }
        data.put("list",result);
        res.put("data",data);
        res.put("pageSize", pageSize);
        res.put("pageNum",pageNum);

        return ResponseEntity.ok(res.toString());
    }

        @RequestMapping("/buy")
        ResponseEntity<?> buyTicket(@RequestBody ticketBuy ticketinfo){
            System.out.println(ticketinfo.getUseraccount());
            Integer code = this.buyTicketMapper.buyTicket(ticketinfo);
            if (code == -1){
                return ResponseEntity.status(400).body("输入信息有误");
            }else{
                return ResponseEntity.ok("success");
            }
    }
    @RequestMapping("/reject")
    ResponseEntity<?> rejectTicket(@RequestBody reqReject reqreject){
        System.out.println(reqreject.getTrainNumber());
        this.buyTicketMapper.rejectTicket(reqreject);
        return ResponseEntity.ok("success");
    }
}
