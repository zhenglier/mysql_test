package com.example.sqlexperiment.controller.LogIn;

import com.example.sqlexperiment.JWT.JwtUtil;
import com.example.sqlexperiment.Mapper.Login.UserMapper;
import com.example.sqlexperiment.Object.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.sqlexperiment.Object.Login.ReqLoginForm;
import com.example.sqlexperiment.Object.Login.ResLogin;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/gettoken")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody ReqLoginForm authenticationRequest) {
        // 此处简化验证过程，实际应用中应连接数据库验证用户名和密码
//        System.out.println("hello world");
        final String username = authenticationRequest.getUsername();
        final String password = authenticationRequest.getPassword();
        System.out.println(password);
        User _user = userMapper.getUserByAccount(username);
        // 这类进行查表使用mybatis进行查询
        // 将模拟取得的密码进行散列
        // 需要注意的是当前这种方式并不安全，如果直到密文可以直接模拟前端发送数据，后端会进行响应
//        final String md5_right_password = MD5Hashing.getMD5(right_password);

//        System.out.println(md5_right_password);
        // 假设验证成功后，生成 JWT 返回
//        System.out.println("user.password");
        if (_user.getPassword().equals(password)) {
            final String jwt = JwtUtil.generateToken(username);
            Map<String, Object> response = new HashMap<>();
            Map<String, Object>data = new HashMap<>();
            data.put("access_token", jwt);
            response.put("data", data);
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body("用户名或密码错误");
        }
    }
}
